[![Open in Visual Studio Code](https://classroom.github.com/assets/open-in-vscode-718a45dd9cf7e7f842a935f5ebbe5719a5e09af4491e668f4dbf3b35d5cca122.svg)](https://classroom.github.com/online_ide?assignment_repo_id=14047528&assignment_repo_type=AssignmentRepo)
Description:
Design and develop owners biography page and cafeteria main page.Follow the rubrics to get awarded with best marks.The assignment due is on march 1 st 11:59 pm.
Push your files to github and zip the files to upload on canvas as well.
